
import { useState, useEffect } from 'react';

interface Video {
  id: string;
  title: string;
  file: File | null;
  url: string;
  uploadDate: string;
}

// IndexedDB utilities for storing video files
const DB_NAME = 'CourseVideoDB';
const DB_VERSION = 1;
const STORE_NAME = 'videos';

const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
  });
};

const saveVideoFile = async (id: string, file: File): Promise<void> => {
  const db = await openDB();
  const transaction = db.transaction([STORE_NAME], 'readwrite');
  const store = transaction.objectStore(STORE_NAME);
  
  await new Promise((resolve, reject) => {
    const request = store.put({ id, file });
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
};

const getVideoFile = async (id: string): Promise<File | null> => {
  try {
    const db = await openDB();
    const transaction = db.transaction([STORE_NAME], 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    
    return new Promise((resolve, reject) => {
      const request = store.get(id);
      request.onsuccess = () => {
        const result = request.result;
        resolve(result ? result.file : null);
      };
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error('Error getting video file:', error);
    return null;
  }
};

const deleteVideoFile = async (id: string): Promise<void> => {
  try {
    const db = await openDB();
    const transaction = db.transaction([STORE_NAME], 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    
    await new Promise((resolve, reject) => {
      const request = store.delete(id);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error('Error deleting video file:', error);
  }
};

export const useVideoManagement = () => {
  const [videos, setVideos] = useState<Video[]>([]);

  // Load videos from localStorage and restore files from IndexedDB
  useEffect(() => {
    const loadVideos = async () => {
      const savedVideos = localStorage.getItem('courseVideos');
      if (savedVideos) {
        try {
          const parsedVideos = JSON.parse(savedVideos);
          
          // Restore files from IndexedDB and create URLs
          const videosWithFiles = await Promise.all(
            parsedVideos.map(async (video: any) => {
              const file = await getVideoFile(video.id);
              return {
                ...video,
                file,
                url: file ? URL.createObjectURL(file) : ''
              };
            })
          );
          
          setVideos(videosWithFiles);
        } catch (error) {
          console.error('Error loading videos:', error);
        }
      }
    };

    loadVideos();
  }, []);

  // Save video metadata to localStorage (without file data)
  useEffect(() => {
    const videosForStorage = videos.map(video => ({
      id: video.id,
      title: video.title,
      uploadDate: video.uploadDate
    }));
    localStorage.setItem('courseVideos', JSON.stringify(videosForStorage));
  }, [videos]);

  const addVideo = async (title: string, file: File) => {
    const id = Date.now().toString();
    const url = URL.createObjectURL(file);
    
    const newVideo: Video = {
      id,
      title,
      file,
      url,
      uploadDate: new Date().toLocaleDateString()
    };

    // Save file to IndexedDB
    try {
      await saveVideoFile(id, file);
      setVideos(prev => [...prev, newVideo]);
    } catch (error) {
      console.error('Error saving video file:', error);
      // Still add the video but without persistence
      setVideos(prev => [...prev, newVideo]);
    }
  };

  const deleteVideo = async (id: string) => {
    const videoToDelete = videos.find(v => v.id === id);
    if (videoToDelete?.url) {
      URL.revokeObjectURL(videoToDelete.url);
    }
    
    // Delete from IndexedDB
    await deleteVideoFile(id);
    
    const updatedVideos = videos.filter(v => v.id !== id);
    setVideos(updatedVideos);
    
    // Update localStorage
    if (updatedVideos.length === 0) {
      localStorage.removeItem('courseVideos');
    }
  };

  return {
    videos,
    addVideo,
    deleteVideo
  };
};

export type { Video };
