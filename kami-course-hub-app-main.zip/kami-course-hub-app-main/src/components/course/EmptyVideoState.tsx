
import { Button } from '@/components/ui/button';
import { Upload, Plus } from 'lucide-react';

interface EmptyVideoStateProps {
  onAddVideo: () => void;
}

const EmptyVideoState = ({ onAddVideo }: EmptyVideoStateProps) => {
  return (
    <div className="text-center py-16">
      <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-8 border border-white/10 max-w-md mx-auto">
        <Upload className="h-16 w-16 text-purple-400 mx-auto mb-4" />
        <h3 className="text-xl font-bold text-white mb-2">No Videos Yet</h3>
        <p className="text-gray-300 mb-6">
          Start building your course by uploading your first video
        </p>
        <Button
          onClick={onAddVideo}
          className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
        >
          <Plus className="h-4 w-4 mr-2" />
          Upload First Video
        </Button>
      </div>
    </div>
  );
};

export default EmptyVideoState;
