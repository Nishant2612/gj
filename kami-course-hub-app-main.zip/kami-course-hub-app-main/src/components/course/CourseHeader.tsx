
import { Button } from '@/components/ui/button';
import { ArrowLeft, Plus } from 'lucide-react';

interface CourseHeaderProps {
  onBack: () => void;
  onAddVideo: () => void;
}

const CourseHeader = ({ onBack, onAddVideo }: CourseHeaderProps) => {
  return (
    <header className="bg-white/10 backdrop-blur-lg border-b border-white/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-4">
            <Button
              onClick={onBack}
              variant="ghost"
              className="text-white hover:bg-white/10"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
          
          <h1 className="text-2xl font-bold text-white">PW Course</h1>
          
          <Button 
            onClick={onAddVideo}
            className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Video
          </Button>
        </div>
      </div>
    </header>
  );
};

export default CourseHeader;
