
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Play, Trash2, Upload } from 'lucide-react';
import { Video } from '@/hooks/useVideoManagement';

interface VideoGridProps {
  videos: Video[];
  onDeleteVideo: (id: string) => void;
}

const VideoGrid = ({ videos, onDeleteVideo }: VideoGridProps) => {
  const handlePlayVideo = (video: Video) => {
    if (!video.url) {
      alert('Video file is not available. Please re-upload the video.');
      return;
    }
    
    const videoElement = document.createElement('video');
    videoElement.src = video.url;
    videoElement.controls = true;
    videoElement.style.width = '100%';
    const newWindow = window.open('', '_blank');
    if (newWindow) {
      newWindow.document.body.appendChild(videoElement);
      newWindow.document.title = video.title;
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {videos.map((video) => (
        <Card 
          key={video.id} 
          className="bg-white/10 backdrop-blur-lg border-white/20 hover:bg-white/15 transition-all duration-300"
        >
          <CardHeader>
            <CardTitle className="text-white text-lg truncate">
              {video.title}
            </CardTitle>
            <CardDescription className="text-gray-300">
              Uploaded on {video.uploadDate}
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-4">
            {/* Video preview */}
            <div className="aspect-video bg-black rounded-lg overflow-hidden flex items-center justify-center">
              {video.url ? (
                <video
                  src={video.url}
                  className="w-full h-full object-cover"
                  controls
                  preload="metadata"
                >
                  Your browser does not support the video tag.
                </video>
              ) : (
                <div className="text-gray-400 text-center p-4">
                  <Upload className="h-8 w-8 mx-auto mb-2" />
                  <p className="text-sm">Video file not available</p>
                  <p className="text-xs">Please re-upload</p>
                </div>
              )}
            </div>
            
            {/* Actions */}
            <div className="flex space-x-2">
              <Button
                size="sm"
                className="flex-1 bg-green-600 hover:bg-green-700"
                onClick={() => handlePlayVideo(video)}
                disabled={!video.url}
              >
                <Play className="h-4 w-4 mr-1" />
                Play
              </Button>
              
              <Button
                size="sm"
                variant="destructive"
                onClick={() => onDeleteVideo(video.id)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default VideoGrid;
