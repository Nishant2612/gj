
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Upload } from 'lucide-react';

interface VideoUploadDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onUpload: (title: string, file: File) => void;
}

const VideoUploadDialog = ({ isOpen, onOpenChange, onUpload }: VideoUploadDialogProps) => {
  const [videoTitle, setVideoTitle] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('video/')) {
      setSelectedFile(file);
    } else {
      alert('Please select a valid video file');
    }
  };

  const handleUpload = () => {
    if (!videoTitle || !selectedFile) {
      alert('Please provide a title and select a video file');
      return;
    }

    onUpload(videoTitle, selectedFile);
    setVideoTitle('');
    setSelectedFile(null);
    onOpenChange(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="bg-slate-900 border-white/20">
        <DialogHeader>
          <DialogTitle className="text-white">Upload New Video</DialogTitle>
          <DialogDescription className="text-gray-300">
            Add a new video to your course collection
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title" className="text-white">Video Title</Label>
            <Input
              id="title"
              placeholder="Enter video title"
              value={videoTitle}
              onChange={(e) => setVideoTitle(e.target.value)}
              className="bg-white/10 border-white/20 text-white placeholder:text-gray-300"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="video" className="text-white">Select Video File</Label>
            <Input
              id="video"
              type="file"
              accept="video/*"
              onChange={handleFileSelect}
              className="bg-white/10 border-white/20 text-white file:text-white file:bg-white/10 file:border-white/20"
            />
            {selectedFile && (
              <p className="text-sm text-green-400">
                Selected: {selectedFile.name}
              </p>
            )}
          </div>
          
          <Button
            onClick={handleUpload}
            className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
          >
            <Upload className="h-4 w-4 mr-2" />
            Upload Video
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default VideoUploadDialog;
