
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';

const Index = () => {
  const [showIntro, setShowIntro] = useState(true);
  const navigate = useNavigate();

  const handleGetStarted = () => {
    setShowIntro(false);
    setTimeout(() => {
      navigate('/auth');
    }, 300);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-20 w-72 h-72 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute top-40 right-20 w-72 h-72 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse animation-delay-2000"></div>
        <div className="absolute -bottom-8 left-40 w-72 h-72 bg-indigo-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse animation-delay-4000"></div>
      </div>

      {showIntro ? (
        <div className="relative z-10 min-h-screen flex items-center justify-center">
          <div className="text-center animate-fade-in">
            {/* Main title with dramatic effect */}
            <h1 className="text-6xl md:text-8xl font-bold text-white mb-8 tracking-wider">
              <span className="bg-gradient-to-r from-purple-400 via-pink-500 to-blue-500 bg-clip-text text-transparent animate-scale-in">
                WELCOME TO
              </span>
            </h1>
            
            <h2 className="text-7xl md:text-9xl font-extrabold text-white mb-12 tracking-widest drop-shadow-2xl animate-fade-in animation-delay-1000">
              <span className="bg-gradient-to-r from-yellow-400 via-red-500 to-pink-500 bg-clip-text text-transparent">
                NK KAMI
              </span>
            </h2>

            <p className="text-xl md:text-2xl text-gray-300 mb-12 max-w-2xl mx-auto animate-fade-in animation-delay-2000">
              Your gateway to premium learning experiences
            </p>

            {/* Call-to-action button */}
            <Button
              onClick={handleGetStarted}
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-bold py-4 px-12 rounded-full text-xl shadow-2xl transform hover:scale-105 transition-all duration-300 animate-fade-in animation-delay-3000"
            >
              LET'S START
            </Button>
          </div>
        </div>
      ) : (
        <div className="relative z-10 min-h-screen flex items-center justify-center animate-fade-out">
          <div className="text-center">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-white mx-auto"></div>
            <p className="text-white mt-4 text-xl">Redirecting...</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default Index;
