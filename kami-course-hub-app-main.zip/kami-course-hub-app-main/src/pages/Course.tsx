
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useVideoManagement } from '@/hooks/useVideoManagement';
import CourseHeader from '@/components/course/CourseHeader';
import VideoUploadDialog from '@/components/course/VideoUploadDialog';
import EmptyVideoState from '@/components/course/EmptyVideoState';
import VideoGrid from '@/components/course/VideoGrid';

const Course = () => {
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const navigate = useNavigate();
  const { videos, addVideo, deleteVideo } = useVideoManagement();

  useEffect(() => {
    const isAuthenticated = localStorage.getItem('isAuthenticated');
    if (!isAuthenticated) {
      navigate('/auth');
    }
  }, [navigate]);

  const goBack = () => {
    navigate('/dashboard');
  };

  const handleAddVideo = () => {
    setIsUploadOpen(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <CourseHeader onBack={goBack} onAddVideo={handleAddVideo} />

      <VideoUploadDialog
        isOpen={isUploadOpen}
        onOpenChange={setIsUploadOpen}
        onUpload={addVideo}
      />

      {/* Main content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Your Video Library</h2>
          <p className="text-gray-300">
            {videos.length === 0 
              ? 'No videos uploaded yet. Click "Add Video" to get started!' 
              : `${videos.length} video${videos.length === 1 ? '' : 's'} in your collection`
            }
          </p>
        </div>

        {videos.length === 0 ? (
          <EmptyVideoState onAddVideo={handleAddVideo} />
        ) : (
          <VideoGrid videos={videos} onDeleteVideo={deleteVideo} />
        )}
      </main>
    </div>
  );
};

export default Course;
